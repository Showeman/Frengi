import React from 'react';
import { useAuthStore } from '../store/authStore';
import { User, Book, ShoppingBag, Settings } from 'lucide-react';
import Button from '../components/ui/Button';

const Profile = () => {
  const { user, isAuthenticated, openModal, logout } = useAuthStore();

  if (!isAuthenticated) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign in to view your profile</h2>
        <Button onClick={openModal}>Sign In</Button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex items-center space-x-4">
          <div className="bg-orange-100 p-4 rounded-full">
            <User className="w-8 h-8 text-orange-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
            <p className="text-gray-600">{user.email}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatCard
          icon={Book}
          title="Published Books"
          value={user.publishedBooks.length}
        />
        <StatCard
          icon={ShoppingBag}
          title="Purchases"
          value={user.purchases.length}
        />
      </div>

      <div className="mt-8">
        <Button
          variant="secondary"
          icon={Settings}
          onClick={() => {/* Handle settings */}}
          className="mr-4"
        >
          Settings
        </Button>
        <Button
          variant="secondary"
          onClick={logout}
        >
          Sign Out
        </Button>
      </div>
    </div>
  );
};

const StatCard = ({ icon: Icon, title, value }) => (
  <div className="bg-white rounded-lg shadow-sm p-6">
    <div className="flex items-center space-x-3">
      <Icon className="w-6 h-6 text-orange-500" />
      <div>
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <p className="text-3xl font-bold text-orange-500">{value}</p>
      </div>
    </div>
  </div>
);

export default Profile;