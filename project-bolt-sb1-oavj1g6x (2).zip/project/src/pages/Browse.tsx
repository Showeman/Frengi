import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import BookGrid from '../components/book/BookGrid';
import SearchBar from '../components/search/SearchBar';
import FilterPanel from '../components/filter/FilterPanel';
import { FEATURED_BOOKS } from '../data/featured-books';

const Browse = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Browse Books</h1>
      
      <div className="flex flex-col md:flex-row gap-6">
        <aside className="w-full md:w-64">
          <FilterPanel 
            selectedGenre={selectedGenre}
            onGenreChange={setSelectedGenre}
          />
        </aside>

        <main className="flex-1">
          <SearchBar 
            value={searchQuery}
            onChange={setSearchQuery}
          />
          <BookGrid books={FEATURED_BOOKS} />
        </main>
      </div>
    </div>
  );
};

export default Browse;