import React from 'react';
import { ShoppingCart, Trash2 } from 'lucide-react';
import Button from '../components/ui/Button';
import { useAuthStore } from '../store/authStore';
import { FEATURED_BOOKS } from '../data/featured-books';

const Cart = () => {
  const { isAuthenticated, openModal } = useAuthStore();

  if (!isAuthenticated) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign in to view your cart</h2>
        <Button onClick={openModal}>Sign In</Button>
      </div>
    );
  }

  // Mock cart items using featured books
  const cartItems = FEATURED_BOOKS.slice(0, 2);
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Shopping Cart</h1>

      <div className="bg-white rounded-lg shadow-sm divide-y">
        {cartItems.map((item) => (
          <div key={item.id} className="p-4 flex items-center space-x-4">
            <img
              src={item.cover}
              alt={item.title}
              className="w-20 h-20 object-cover rounded"
            />
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{item.title}</h3>
              <p className="text-sm text-gray-600">{item.author}</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-orange-500">${item.price.toFixed(2)}</p>
              <button className="text-red-500 hover:text-red-600">
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}

        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <span className="text-gray-600">Total:</span>
            <span className="text-2xl font-bold text-orange-500">
              ${total.toFixed(2)}
            </span>
          </div>
          <Button variant="primary" className="w-full">
            Checkout
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Cart;