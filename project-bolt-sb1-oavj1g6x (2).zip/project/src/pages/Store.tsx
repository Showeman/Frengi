import React from 'react';
import BookGrid from '../components/book/BookGrid';
import { FEATURED_BOOKS } from '../data/featured-books';
import { Tag, TrendingUp } from 'lucide-react';

const Store = () => {
  return (
    <div className="animate-fade-in">
      <div className="bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl p-8 text-white mb-8">
        <h1 className="text-3xl font-bold mb-4">Bookliv Store</h1>
        <p className="text-lg opacity-90">Discover and purchase amazing books</p>
      </div>

      <section className="mb-12">
        <div className="flex items-center mb-6">
          <TrendingUp className="w-6 h-6 text-orange-500 mr-2" />
          <h2 className="text-2xl font-bold text-gray-900">Trending Now</h2>
        </div>
        <BookGrid books={FEATURED_BOOKS} />
      </section>

      <section>
        <div className="flex items-center mb-6">
          <Tag className="w-6 h-6 text-orange-500 mr-2" />
          <h2 className="text-2xl font-bold text-gray-900">Special Offers</h2>
        </div>
        <BookGrid books={FEATURED_BOOKS.slice(0, 2)} />
      </section>
    </div>
  );
};

export default Store;