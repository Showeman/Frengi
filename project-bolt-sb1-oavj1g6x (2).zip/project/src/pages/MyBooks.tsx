import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import BookGrid from '../components/book/BookGrid';
import { FEATURED_BOOKS } from '../data/featured-books';
import Button from '../components/ui/Button';
import CreateBookModal from '../components/book/CreateBookModal';
import { Plus } from 'lucide-react';

const MyBooks = () => {
  const { isAuthenticated, openModal } = useAuthStore();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign in to view your books</h2>
        <p className="text-gray-600 mb-6">Access your library and manage your books</p>
        <Button onClick={openModal}>Sign In</Button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">My Books</h1>
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setIsCreateModalOpen(true)}
        >
          Create New Book
        </Button>
      </div>
      
      <div className="grid grid-cols-1 gap-6 mb-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Currently Reading</h2>
          <BookGrid books={FEATURED_BOOKS.slice(0, 2)} />
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Library</h2>
          <BookGrid books={FEATURED_BOOKS} />
        </section>
      </div>

      <CreateBookModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </div>
  );
};

export default MyBooks;