import React from 'react';
import WelcomeBanner from '../components/home/WelcomeBanner';
import CategoryPill from '../components/ui/CategoryPill';
import QuickStats from '../components/home/QuickStats';
import FeaturedSection from '../components/home/FeaturedSection';
import { Book, Library, Sparkles, Headphones, Users, Palette, Globe } from 'lucide-react';

const Home = () => {
  return (
    <div className="animate-fade-in space-y-8">
      <WelcomeBanner />

      <div className="flex space-x-4 overflow-x-auto pb-4">
        <CategoryPill icon={Book} label="Fiction 📚" color="bg-blue-50" />
        <CategoryPill icon={Library} label="Self-Study 📖" color="bg-purple-50" />
        <CategoryPill icon={Sparkles} label="Premium ✨" color="bg-yellow-50" isNew />
        <CategoryPill icon={Headphones} label="Audio Books 🎧" color="bg-green-50" />
        <CategoryPill icon={Users} label="Book Clubs 👥" color="bg-pink-50" isNew />
        <CategoryPill icon={Palette} label="Art Books 🎨" color="bg-orange-50" />
        <CategoryPill icon={Globe} label="International 🌍" color="bg-teal-50" />
      </div>

      <QuickStats />

      <div className="relative">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-br from-blue-200 to-cyan-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000" />
        
        <div className="relative">
          <FeaturedSection />
        </div>
      </div>
    </div>
  );
};

export default Home;