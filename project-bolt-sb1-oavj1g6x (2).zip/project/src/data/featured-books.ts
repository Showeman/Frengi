import { Book } from '../types';

export const FEATURED_BOOKS: Book[] = [
  {
    id: '1',
    title: 'The Art of Reading',
    author: 'Sarah Johnson',
    cover: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80',
    rating: 4.5,
    price: 24.99,
    description: 'Discover the joy of reading through this comprehensive guide.'
  },
  {
    id: '2',
    title: 'Digital Future',
    author: 'Michael Chen',
    cover: 'https://images.unsplash.com/photo-1589998059171-988d887df646?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    price: 29.99,
    description: 'Explore the future of technology and its impact on society.'
  },
  {
    id: '3',
    title: 'Creative Writing',
    author: 'Emily Parker',
    cover: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80',
    rating: 4.3,
    price: 19.99,
    description: 'Learn the art of storytelling and creative writing.'
  }
];