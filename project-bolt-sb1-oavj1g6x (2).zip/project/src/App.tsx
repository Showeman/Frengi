import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Browse from './pages/Browse';
import MyBooks from './pages/MyBooks';
import Store from './pages/Store';
import Profile from './pages/Profile';
import Cart from './pages/Cart';
import Modal from './components/ui/Modal';
import LoginForm from './components/auth/LoginForm';
import FloatingMenu from './components/navigation/FloatingMenu';
import { useAuthStore } from './store/authStore';

function App() {
  const { isModalOpen, closeModal } = useAuthStore();

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/browse" element={<Browse />} />
          <Route path="/my-books" element={<MyBooks />} />
          <Route path="/store" element={<Store />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/cart" element={<Cart />} />
        </Routes>

        <FloatingMenu />

        <Modal
          isOpen={isModalOpen}
          onClose={closeModal}
          title="Sign In"
        >
          <LoginForm />
        </Modal>
      </Layout>
    </Router>
  );
}

export default App;