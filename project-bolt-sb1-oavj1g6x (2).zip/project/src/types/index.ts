export interface Book {
  id: string;
  title: string;
  author: string;
  cover: string;
  rating: number;
  price: number;
  description: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  purchases: string[];
  publishedBooks: string[];
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  isModalOpen: boolean;
}