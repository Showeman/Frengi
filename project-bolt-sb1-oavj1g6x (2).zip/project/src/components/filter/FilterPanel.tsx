import React from 'react';

const GENRES = [
  'Fiction',
  'Non-Fiction',
  'Science Fiction',
  'Mystery',
  'Romance',
  'Biography',
  'History',
  'Self-Help'
];

interface FilterPanelProps {
  selectedGenre: string | null;
  onGenreChange: (genre: string | null) => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ selectedGenre, onGenreChange }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h3 className="font-semibold text-gray-900 mb-4">Genres</h3>
      <div className="space-y-2">
        {GENRES.map((genre) => (
          <label
            key={genre}
            className="flex items-center space-x-2 text-sm cursor-pointer"
          >
            <input
              type="radio"
              name="genre"
              checked={selectedGenre === genre}
              onChange={() => onGenreChange(genre)}
              className="text-orange-500 focus:ring-orange-500"
            />
            <span className="text-gray-700">{genre}</span>
          </label>
        ))}
      </div>
      {selectedGenre && (
        <button
          onClick={() => onGenreChange(null)}
          className="mt-4 text-sm text-orange-500 hover:text-orange-600"
        >
          Clear Filter
        </button>
      )}
    </div>
  );
};

export default FilterPanel;