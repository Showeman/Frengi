import React from 'react';
import { Bell, Gift, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const TopNav = () => {
  return (
    <div className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link to="/" className="text-2xl font-bold text-gray-900">
              Bookliv
            </Link>
            <nav className="hidden md:flex space-x-6">
              <NavLink to="/" label="Home" />
              <NavLink to="/browse" label="Browse" />
              <NavLink to="/my-books" label="My Books" />
              <NavLink to="/store" label="Store" />
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-gray-100 rounded-full relative">
              <Bell className="w-6 h-6 text-gray-600" />
              <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                2
              </span>
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Gift className="w-6 h-6 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <MessageCircle className="w-6 h-6 text-gray-600" />
            </button>
            <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-400 to-purple-500" />
          </div>
        </div>
      </div>
    </div>
  );
};

const NavLink = ({ to, label }) => (
  <Link
    to={to}
    className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
  >
    {label}
  </Link>
);

export default TopNav;