import React from 'react';
import { Home, Library, BookOpen, ShoppingBag, User, ShoppingCart } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';

const FloatingMenu = () => {
  const location = useLocation();

  return (
    <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-white rounded-full shadow-lg px-6 py-3 flex space-x-8 animate-fade-up">
      <NavItem 
        to="/" 
        icon={<Home className="w-5 h-5" />}
        active={location.pathname === '/'} 
      />
      <NavItem 
        to="/browse" 
        icon={<Library className="w-5 h-5" />}
        active={location.pathname === '/browse'} 
      />
      <NavItem 
        to="/my-books" 
        icon={<BookOpen className="w-5 h-5" />}
        active={location.pathname === '/my-books'} 
      />
      <NavItem 
        to="/cart" 
        icon={<ShoppingCart className="w-5 h-5" />}
        active={location.pathname === '/cart'} 
      />
      <NavItem 
        to="/profile" 
        icon={<User className="w-5 h-5" />}
        active={location.pathname === '/profile'} 
      />
    </div>
  );
};

const NavItem = ({ to, icon, active }) => (
  <Link
    to={to}
    className={`p-2 rounded-full transition-colors duration-200
      ${active ? 'text-orange-500 bg-orange-50' : 'text-gray-600 hover:text-orange-500 hover:bg-orange-50'}`}
  >
    {icon}
  </Link>
);

export default FloatingMenu;