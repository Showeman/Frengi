import React from 'react';
import { LucideIcon } from 'lucide-react';

interface CategoryPillProps {
  icon: LucideIcon;
  label: string;
  isNew?: boolean;
  color?: string;
}

const CategoryPill: React.FC<CategoryPillProps> = ({ 
  icon: Icon, 
  label, 
  isNew, 
  color = 'bg-blue-50' 
}) => {
  return (
    <div 
      className={`
        ${color} rounded-full px-4 py-2 flex items-center space-x-2 
        transition-all duration-300 hover:scale-105 hover:shadow-md
        animate-scale
      `}
    >
      <Icon className="w-5 h-5 text-gray-700" />
      <span className="text-sm font-medium text-gray-900">{label}</span>
      {isNew && (
        <span className="bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs px-2 py-0.5 rounded-full animate-pulse">
          New
        </span>
      )}
    </div>
  );
};

export default CategoryPill;