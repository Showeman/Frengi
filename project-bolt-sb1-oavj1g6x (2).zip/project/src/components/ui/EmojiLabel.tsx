import React from 'react';

interface EmojiLabelProps {
  emoji: string;
  label: string;
  className?: string;
}

const EmojiLabel: React.FC<EmojiLabelProps> = ({ emoji, label, className = '' }) => {
  return (
    <span className={`inline-flex items-center space-x-2 ${className}`}>
      <span className="text-xl">{emoji}</span>
      <span>{label}</span>
    </span>
  );
};

export default EmojiLabel;