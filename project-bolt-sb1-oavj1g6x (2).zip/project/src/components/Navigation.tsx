import React from 'react';
import { Home, Library, BookOpen, ShoppingBag } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}

const Navigation = () => {
  const location = useLocation();

  return (
    <nav className="bg-white shadow-sm border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex space-x-8">
            <NavItem 
              to="/" 
              icon={<Home className="w-5 h-5" />} 
              label="Home" 
              active={location.pathname === '/'} 
            />
            <NavItem 
              to="/browse" 
              icon={<Library className="w-5 h-5" />} 
              label="Browse" 
              active={location.pathname === '/browse'} 
            />
            <NavItem 
              to="/my-books" 
              icon={<BookOpen className="w-5 h-5" />} 
              label="My Books" 
              active={location.pathname === '/my-books'} 
            />
            <NavItem 
              to="/store" 
              icon={<ShoppingBag className="w-5 h-5" />} 
              label="Store" 
              active={location.pathname === '/store'} 
            />
          </div>
        </div>
      </div>
    </nav>
  );
};

const NavItem: React.FC<NavItemProps> = ({ icon, label, active = false, to }) => (
  <Link
    to={to}
    className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium
      transition-colors duration-200 ease-in-out
      ${active 
        ? 'text-orange-500 bg-orange-50' 
        : 'text-gray-600 hover:text-orange-500 hover:bg-orange-50'
      }`}
  >
    {icon}
    <span>{label}</span>
  </Link>
);

export default Navigation;