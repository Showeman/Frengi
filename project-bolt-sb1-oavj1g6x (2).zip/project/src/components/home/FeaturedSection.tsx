import React from 'react';
import { FEATURED_BOOKS } from '../../data/featured-books';
import GlassCard from '../ui/GlassCard';
import EmojiLabel from '../ui/EmojiLabel';
import { Sparkles } from 'lucide-react';

const FeaturedSection = () => {
  return (
    <section className="relative">
      {/* Decorative blur effects */}
      <div className="absolute -top-10 -left-10 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob" />
      <div className="absolute -bottom-8 -right-8 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob animation-delay-2000" />
      
      <div className="relative">
        <div className="flex items-center space-x-3 mb-6">
          <Sparkles className="w-6 h-6 text-yellow-500" />
          <h2 className="text-2xl font-bold text-gray-900">Featured Books</h2>
          <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
            Hot 🔥
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURED_BOOKS.map((book) => (
            <GlassCard key={book.id} className="p-6 transform hover:scale-105 transition-all">
              <img
                src={book.cover}
                alt={book.title}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="font-semibold text-gray-900 mb-2">{book.title}</h3>
              <div className="flex items-center space-x-2 mb-3">
                <EmojiLabel emoji="✍️" label={book.author} />
              </div>
              <div className="flex justify-between items-center">
                <EmojiLabel 
                  emoji="⭐" 
                  label={`${book.rating}`} 
                  className="text-yellow-600"
                />
                <span className="text-purple-600 font-bold">
                  ${book.price}
                </span>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedSection;