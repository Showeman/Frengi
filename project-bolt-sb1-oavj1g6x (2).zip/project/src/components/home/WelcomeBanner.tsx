import React from 'react';
import Button from '../ui/Button';
import { BookOpen } from 'lucide-react';

const WelcomeBanner = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary-light/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse animation-delay-2000" />
      
      <div className="relative bg-gradient-to-r from-primary to-secondary rounded-3xl p-8 text-white">
        <div className="flex justify-between items-center">
          <div className="animate-scale">
            <h1 className="text-4xl font-bold mb-4">Welcome to Bookliv</h1>
            <p className="text-lg opacity-90 mb-6">
              Your journey through stories begins here
            </p>
            <Button 
              variant="outline" 
              icon={BookOpen}
              className="border-white text-white hover:bg-white/20 hover:border-white"
            >
              Start Reading
            </Button>
          </div>
          
          {/* Floating Books Animation */}
          <div className="hidden lg:flex space-x-6">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="relative w-24 h-32 animate-float"
                style={{ 
                  animationDelay: `${i * 0.5}s`,
                  transform: `rotate(${6 * (i + 1)}deg)`
                }}
              >
                <div className="absolute inset-0 bg-white/10 backdrop-blur-sm rounded-lg" />
                <div className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent rounded-lg" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeBanner;