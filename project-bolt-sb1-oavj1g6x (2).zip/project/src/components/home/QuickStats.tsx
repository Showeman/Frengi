import React from 'react';
import GlassCard from '../ui/GlassCard';
import EmojiLabel from '../ui/EmojiLabel';

const stats = [
  { emoji: "📚", label: "Books Read", value: "124" },
  { emoji: "⭐", label: "Reviews", value: "48" },
  { emoji: "🎯", label: "Reading Goal", value: "75%" },
  { emoji: "🏆", label: "Achievements", value: "12" },
];

const QuickStats = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map(({ emoji, label, value }) => (
        <GlassCard key={label} className="p-4 text-center">
          <EmojiLabel
            emoji={emoji}
            label={label}
            className="mb-2 justify-center"
          />
          <p className="text-2xl font-bold text-purple-600">{value}</p>
        </GlassCard>
      ))}
    </div>
  );
};

export default QuickStats;