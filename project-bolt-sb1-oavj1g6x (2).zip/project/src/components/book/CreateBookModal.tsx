import React, { useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';

interface CreateBookModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CreateBookModal: React.FC<CreateBookModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    genre: '',
    ageGroup: '',
    accessibility: 'public',
    price: ''
  });

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const progress = (step / 5) * 100;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create New Book">
      <div className="mb-6">
        <div className="relative pt-1">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block text-orange-500">
                Step {step} of 5
              </span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-orange-100">
            <div
              style={{ width: `${progress}%` }}
              className="animate-[width] shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-orange-500 transition-all duration-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          {step === 1 && (
            <div className="animate-fade-in">
              <label className="block text-sm font-medium text-gray-700">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => updateField('title', e.target.value)}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
                placeholder="Enter book title"
              />
            </div>
          )}

          {step === 2 && (
            <div className="animate-fade-in">
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => updateField('description', e.target.value)}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
                rows={4}
                placeholder="Enter book description"
              />
            </div>
          )}

          {step === 3 && (
            <div className="animate-fade-in">
              <label className="block text-sm font-medium text-gray-700">Genre</label>
              <select
                value={formData.genre}
                onChange={(e) => updateField('genre', e.target.value)}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
              >
                <option value="">Select genre</option>
                <option value="fiction">Fiction</option>
                <option value="non-fiction">Non-Fiction</option>
                <option value="mystery">Mystery</option>
                <option value="romance">Romance</option>
              </select>
            </div>
          )}

          {step === 4 && (
            <div className="animate-fade-in">
              <label className="block text-sm font-medium text-gray-700">Age Group</label>
              <select
                value={formData.ageGroup}
                onChange={(e) => updateField('ageGroup', e.target.value)}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
              >
                <option value="">Select age group</option>
                <option value="children">Children</option>
                <option value="young-adult">Young Adult</option>
                <option value="adult">Adult</option>
              </select>
            </div>
          )}

          {step === 5 && (
            <div className="animate-fade-in space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Accessibility</label>
                <select
                  value={formData.accessibility}
                  onChange={(e) => updateField('accessibility', e.target.value)}
                  className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
                >
                  <option value="public">Public (Free)</option>
                  <option value="paid">Paid</option>
                </select>
              </div>

              {formData.accessibility === 'paid' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">Price ($)</label>
                  <input
                    type="number"
                    value={formData.price}
                    onChange={(e) => updateField('price', e.target.value)}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 focus:border-orange-500 focus:outline-none focus:ring-orange-500"
                    placeholder="Enter price"
                    min="0.99"
                    step="0.01"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-between">
          {step > 1 && (
            <Button
              variant="secondary"
              onClick={() => setStep(s => s - 1)}
            >
              Previous
            </Button>
          )}
          
          <Button
            variant="primary"
            onClick={() => {
              if (step < 5) {
                setStep(s => s + 1);
              } else {
                // Handle form submission
                console.log('Form submitted:', formData);
                onClose();
              }
            }}
            className="ml-auto"
          >
            {step === 5 ? 'Create Book' : 'Next'}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default CreateBookModal;