import React from 'react';
import { Star, ShoppingCart } from 'lucide-react';
import type { Book } from '../../types';
import Button from '../ui/Button';
import Card from '../ui/Card';

interface BookCardProps {
  book: Book;
}

const BookCard: React.FC<BookCardProps> = ({ book }) => {
  return (
    <Card className="overflow-hidden group">
      <div className="relative">
        <img
          src={book.cover}
          alt={book.title}
          className="w-full h-48 object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 truncate">
          {book.title}
        </h3>
        <p className="text-sm text-gray-600 mb-2">{book.author}</p>
        
        <div className="flex items-center mb-3">
          <Star className="w-4 h-4 text-yellow-400 fill-current" />
          <span className="ml-1 text-sm text-gray-600">{book.rating}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            ${book.price.toFixed(2)}
          </span>
          <Button 
            variant="primary"
            size="sm"
            icon={ShoppingCart}
          >
            Add
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default BookCard;