import React from 'react';
import { Book } from '../../types';

interface BookProgressProps {
  book: Book;
  progress: number;
}

const BookProgress: React.FC<BookProgressProps> = ({ book, progress }) => {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start space-x-4">
        <img
          src={book.cover}
          alt={book.title}
          className="w-20 h-28 object-cover rounded-lg"
        />
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">{book.title}</h3>
          <p className="text-sm text-gray-600 mb-4">{book.author}</p>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Progress</span>
              <span className="text-blue-500 font-medium">{progress}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>
      
      <button className="mt-4 w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors">
        Continue Reading
      </button>
    </div>
  );
};

export default BookProgress;