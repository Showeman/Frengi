import React from 'react';
import BookCard from './BookCard';
import type { Book } from '../../types';

interface BookGridProps {
  books: Book[];
}

const BookGrid: React.FC<BookGridProps> = ({ books }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {books.map((book, index) => (
        <div
          key={book.id}
          className="animate-fade-up"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <BookCard book={book} />
        </div>
      ))}
    </div>
  );
};

export default BookGrid;