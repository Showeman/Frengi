export const theme = {
  colors: {
    primary: {
      light: '#8B5CF6', // Purple
      DEFAULT: '#6D28D9',
      dark: '#5B21B6',
    },
    secondary: {
      light: '#60A5FA', // Blue
      DEFAULT: '#3B82F6',
      dark: '#2563EB',
    },
    accent: {
      light: '#F472B6', // Pink
      DEFAULT: '#EC4899',
      dark: '#DB2777',
    },
    background: {
      light: '#F3F4F6',
      DEFAULT: '#F9FAFB',
      dark: '#E5E7EB',
    }
  },
  gradients: {
    primary: 'from-purple-500 to-blue-500',
    secondary: 'from-blue-500 to-purple-500',
    accent: 'from-pink-500 to-purple-500',
  }
};