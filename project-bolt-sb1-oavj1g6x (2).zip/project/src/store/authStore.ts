import { create } from 'zustand';
import type { AuthState } from '../types';

export const useAuthStore = create<AuthState & {
  openModal: () => void;
  closeModal: () => void;
  login: (email: string, password: string) => void;
  logout: () => void;
}>((set) => ({
  isAuthenticated: false,
  user: null,
  isModalOpen: false,
  openModal: () => set({ isModalOpen: true }),
  closeModal: () => set({ isModalOpen: false }),
  login: (email, password) => {
    // Simulate login
    set({
      isAuthenticated: true,
      user: {
        id: '1',
        name: 'John Doe',
        email,
        purchases: [],
        publishedBooks: [],
      },
    });
  },
  logout: () => set({ isAuthenticated: false, user: null }),
}));